//pattern 10
let n =5;
let str10= '';
for (let row=1;row<=n;row++){
    for(col= 1; col<=row; col++){
        str10 += '*';
    }
    str10+= '\n';
}
console.log(str10);

//pattern 11
let str11= '';
for (let row= 1;row<=n;row++){
    for (let col=1;col<=row;col++){
        str11 += row;
    }
    str11 += '\n';
}
console.log(str11);

//pattern 12
let str12= '';
for (let row=1;row<=n;row++){
    for (let col=1; col<=row;col++){
        str12+= col;
    }
    str12 += '\n';
}
console.log(str12);

//pattern 13
let str13= '';
for (let row=1; row<=n;row++){
    for (let col=1; col<=row;col++){
        let x= String.fromCharCode(64+row);
        str13 += x;
    }
    str13 += '\n';
}
console.log(str13);

//pattern 14
let str14='';
for(let row=1;row<=n;row++){
    for (let col=1; col<=row;col++){
        let x =String.fromCharCode(64+col);
        str14 += x;
    }
    str14 += '\n';
}
console.log(str14);

//pattern 15
let str15='';
for (let row=1; row<=n;row++){
    let totalColsInARow= n-row+1;
    for(let col=1;col<=totalColsInARow;col++){
        str15 += '*';
    }
    str15 += '\n';
}
console.log(str15);

//pattern 19
let str19='';
for (let row=1;row<=n;row++){
    let totalColsInARow= n-row+1;
    for(let col=1;col<=totalColsInARow;col++){
        let x= String.fromCharCode(64+col);
        str19+= x;
    }
    str19+= '\n';
}
console.log(str19);

//pattern 20
let str20='';
for (let row=1;row<=n;row++){
    let totalColsInARow= n-row+1;
for (let col=1;col<=totalColsInARow;col++){
    str20 += totalColsInARow;
}
str20 +='\n';
}
console.log(str20);

//pattern 21
let str21 ='';
for (let row=1;row<=n;row++){
    let totalColsInARow= n-row+1;
for (let col=1;col<=totalColsInARow;col++){
    str21 += n+1-col;
}
str21 +='\n';
}
console.log(str21);

//pattern 22
let str22 ='';
for (let row=1;row<=n;row++){
    let totalColsInARow= n-row+1;
for (let col=1;col<=totalColsInARow;col++){
    let x =String.fromCharCode(70-row);
        str22 += x;
}
str22 +='\n';
}
console.log(str22);
