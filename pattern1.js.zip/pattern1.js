//pattern 1
let str1='';
let n= 5;
for(let row=1; row<=n;row++){
    for(let col=1;col<=n;col++){
        str1+= '*';
    }
    str1+= '\n';
}
console.log(str1);

//pattern 2
let str2= '';
for(let row=1;row<=n;row++){
    for(let col=1;col<=n;col++){
        str2+= row;
    }
    str2 += '\n';
}
console.log(str2);

//pattern 3
let str3='';
for(let row=1;row<=n;row++){
    for(let col=1;col<=n;col++){
        str3 += col;
    }
    str3 += '\n';
}
console.log(str3);

//pattern 4
let str4 ='';
for(let row=0;row<n;row++){
    for(let col=0;col<n;col++){
     let x= String.fromCharCode(65+row);
        str4 += x; 
    }
    str4 += '\n';
}
console.log(str4);

//pattern 5
let str5='';
for(let row=0;row<n;row++){
    for(let col=0;col<n;col++){
        let x=String.fromCharCode(65+col);
        str5+= x;   
    }
    str5 += '\n';
}
console.log(str5);

//pattern 7
let str7='';
for(let row=0;row<n;row++){
    for(let col=1;col<=n;col++){
        str7+= n-col+1;
    }
    str7+= '\n';
}
console.log(str7);

//pattern 8
let str8='';
for (let row=0;row<n;row++){
    for(let col=1;col<=n;col++){
        let x= String.fromCharCode(69-row);
        str8+= x;
    }
    str8 +='\n';
}
console.log(str8);

//pattern 9
let str9='';
for (let row=0;row<n;row++){
    for(let col=0;col<n;col++){
        let x= String.fromCharCode(69-col);
        str9 += x;
    }
    str9 += '\n';
}
console.log(str9);